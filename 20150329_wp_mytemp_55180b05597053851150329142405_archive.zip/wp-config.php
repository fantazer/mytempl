<?php
/**
 * Основные параметры WordPress.
 *
 * Этот файл содержит следующие параметры: настройки MySQL, префикс таблиц,
 * секретные ключи и ABSPATH. Дополнительную информацию можно найти на странице
 * {@link http://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Кодекса. Настройки MySQL можно узнать у хостинг-провайдера.
 *
 * Этот файл используется скриптом для создания wp-config.php в процессе установки.
 * Необязательно использовать веб-интерфейс, можно скопировать этот файл
 * с именем "wp-config.php" и заполнить значения вручную.
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('WP_CACHE', false); //Added by WP-Cache Manager
define( 'WPCACHEHOME', '' ); //Added by WP-Cache Manager
define('DB_NAME', 'remont');

/** Имя пользователя MySQL */
define('DB_USER', 'fantazer');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', '924748kuz');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '42i:|,A+s=_Kw|R}m]r79#QF8su$#J(v3A$Y*FGVB8m:7fC,/g%(iA-.{$[uxH6[');
define('SECURE_AUTH_KEY',  '-OqH1-Z2_#jd(<jRcdLAh>mIzSvt1Xu7BbWrU~-H=zPMH(;4>.h`{fsXJxLSR,Xp');
define('LOGGED_IN_KEY',    'TYkHGt+d]+T)_VUkuE^U!6AfJLw+bV2fMzGV+MRG}Y-ej0jb|IL<l(Dq3-p*|hy-');
define('NONCE_KEY',        'HgYX_4R-(/EEK~+dQ#^o^StF|=#C yFj?^~5>8EaofEAw(b_u5AU!2-[9X/Vu+3f');
define('AUTH_SALT',        '}dD/7:|TS09QS4RUCnK-t4bz9v+~y(NwJb:7h}EZz~yPT8iHa{)jz+/OQdaw;nO.');
define('SECURE_AUTH_SALT', 'sr|x,Or?ucd!ITc|o!WMK@N`!%piOO&c@|NN+Rs=rA1)!{{|sKf#$U;IaE$J0,U,');
define('LOGGED_IN_SALT',   'JdSXG^QyZg|Nx+qlz1j=UBr@*Xee,89TS4dZ>$~EZ|-m@6f<iDn;ucS>,@vwH:uD');
define('NONCE_SALT',       'D^W-=88d91/qei-N5L9H: +&#T}Ex^NGMmy#<Ay;c[^C3Zd+4Q%0hM>KR+_|3dE=');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
